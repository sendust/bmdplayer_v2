<!DOCTYPE html>
<html>
<head>
<script>
function startTime() {
  var today = new Date();
  var h = today.getHours();
  var m = today.getMinutes();
  var s = today.getSeconds();
  var mm = today.getMilliseconds();
  m = checkTime(m);
  s = checkTime(s);
  document.getElementById('txt').innerHTML =
  h + ":" + m + ":" + s + "." + mm;
  setTimeout(startTime, 50);
}
function checkTime(i) {
  if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
  return i;
}
</script>
</head>

<?php

error_reporting(E_ALL | E_STRICT);
$socket = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);

socket_bind($socket, '127.0.0.1', 40000);
$fromAddr = "";
$fromPort = 0;
$rbyte = 0;
?>

<?php
//$rbyte = socket_recvfrom($socket, $buffer, 32, 0, $fromAddr, $fromPort);
//echo "[$i - $rbyte - {$fromAddr}:{$fromPort}]\t{$buffer} </br>";
// Send a test from the command line such as:
// echo "hello" > /dev/udp/127.0.0.1/1337
?>

<body onload="startTime()">

<div id="txt"></div>

</body>
</html>
